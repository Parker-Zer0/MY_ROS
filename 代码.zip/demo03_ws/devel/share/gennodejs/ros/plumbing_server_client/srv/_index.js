
"use strict";

let AddInts = require('./AddInts.js')

module.exports = {
  AddInts: AddInts,
};
