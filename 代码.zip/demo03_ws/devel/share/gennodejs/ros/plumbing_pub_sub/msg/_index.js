
"use strict";

let Person = require('./Person.js');

module.exports = {
  Person: Person,
};
