#ifndef _HELLO_H
#define _HELLO_H
/*
    声明：namespace
            |--clss
                |--run

*/

namespace hello_ns{

class MyHello{

public:
    void run();
};

}

#endif